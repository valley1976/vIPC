// Copyright (c) 2026 shangu.
// Developed with DSH (DeepSeek Harness).

#pragma once

#include <chrono>
#include <cstddef>
#include <cstdint>
#include <functional>
#include <memory>
#include <string>
#include <vector>

#include "ipc/channel.h"
#include "data/export.h"
#include "data/recorder_config.h"
#include "data/trigger.h"
#include "time/time.h"

namespace ipc {
class Notification;
}

namespace data {

struct Queue_metrics
{
    std::uint64_t depth_bytes = 0;
    std::uint64_t depth_messages = 0;
    std::uint64_t high_watermark_bytes = 0;
    std::uint64_t overflow_count = 0;
};

struct Write_latency
{
    std::uint64_t p50_us = 0;
    std::uint64_t p95_us = 0;
    std::uint64_t p99_us = 0;
    std::uint64_t max_us = 0;
};

struct Bundle_metrics
{
    std::string name;
    Write_mode mode = Write_mode::SYNC;
    Queue_metrics queue;
    Write_latency latency;
    std::uint64_t enqueued = 0;
    std::uint64_t written = 0;
    std::uint64_t dropped = 0;
    std::uint64_t bytes_written = 0;
    std::uint64_t segment_count = 0;
    std::uint64_t unwritten = 0;
    std::uint64_t pre_roll_truncated = 0;
    std::uint64_t late_triggers = 0;
    std::uint64_t publish_failures = 0;
    std::uint64_t clock_jumps = 0;
    // 录制线程在统计窗口内处于 poll 的时间占比，0..1。
    double busy_ratio = 0.0;
    bool mode_switch_pending = false;
    Write_mode pending_mode = Write_mode::SYNC;
};

// 一个待录制 topic：channel 由调用方创建并保持生命周期覆盖 Recorder。
struct Topic
{
    std::string name;
    ipc::Channel* channel = nullptr;

    std::string schema_name;
    std::string schema_encoding = "jsonschema";
    std::string schema_data = "{}";
    // 空表示按 channel 自动选择：chunk 模式 opaque，scalar 模式 uint64。
    std::string message_encoding;
};

// 已经 attach + subscribe 的 topic；由调用方（通常是 Broker）提供。
// Recorder 接管 subscriber，并自己创建 Reader。
struct Subscriber_topic
{
    std::string name;
    std::unique_ptr<ipc::Channel::Subscriber> subscriber;

    std::string schema_name;
    std::string schema_encoding = "jsonschema";
    std::string schema_data = "{}";
    std::string message_encoding;
};

struct Recorder_options
{
    // Bundle 启动前调用；返回 supervisor 创建的 notification。
    // 为 nullptr 时退回进程内条件变量唤醒。
    using Notification_factory =
        std::function<std::shared_ptr<ipc::Notification>(const std::string&)>;
    Notification_factory notification_factory;

    std::string storage_directory = ".";
    std::size_t max_file_size = 100 * 1024 * 1024;
    // 按文件打开后的 steady 时长切分；0 表示不按时长切分。
    std::chrono::milliseconds max_file_duration{0};
    std::string compression = "none";
    Write_mode write_mode = Write_mode::SYNC;
    std::size_t max_queue_bytes = 64 * 1024 * 1024;
    // 空闲时的最长等待；Trigger 边界和 notify() 可以提前唤醒。
    std::chrono::milliseconds poll_interval{100};
    // 每个 topic 每次 poll 最多读取的消息数；防止高频 topic 饿死其它 topic。
    std::size_t max_reads_per_poll = 10;
    // 低延迟部署可开启；失败时静默降级为普通线程。
    bool realtime_thread = false;
    // 0 表示平台默认值；Linux 为 SCHED_FIFO 优先级，Windows 映射为高优先级。
    int realtime_priority = 0;

    // 测试/嵌入时钟；默认使用系统 UTC + steady。
    time_::Clock_source clock_source{};

    // Supervisor 创建的 metrics 共享内存；空表示关闭。
    std::string metrics_shm_name;
    std::string metrics_region_name = "recorder_metrics";
    std::chrono::milliseconds metrics_interval{1000};

    // 一个 Trigger 完成（含 manifest）后回调；回调里可读取 files。
    std::function<void(const Trigger&)> on_trigger_done;
};

// 录制器：按 Trigger 的时间窗口，从 ipc Channel 读消息并写入 MCAP。
class LIBVALLEY_DATA_EXPORT Recorder
{
public:
    using New_file = std::function<void(const std::string& recorder,
                                        const std::string& bundle,
                                        std::size_t sequence,
                                        std::string& file_name)>;
    using Close_file = std::function<void(const std::string& file_name)>;

    Recorder();
    ~Recorder();

    Recorder(const Recorder&) = delete;
    Recorder& operator=(const Recorder&) = delete;

    Recorder(Recorder&& orig) noexcept;
    Recorder& operator=(Recorder&& orig) noexcept;

    [[nodiscard]] static Recorder create(const std::string& name,
                                         const New_file& new_fn = {},
                                         const Close_file& close_fn = {});

    [[nodiscard]] static Recorder create(const std::string& name,
                                         const Recorder_options& options,
                                         const New_file& new_fn = {},
                                         const Close_file& close_fn = {});

    // 多 bundle 配置入口；配置非法时返回空 Recorder。
    [[nodiscard]] static Recorder create(const Recorder_config& config,
                                         const Recorder_options& options,
                                         const New_file& new_fn = {},
                                         const Close_file& close_fn = {});

    [[nodiscard]] bool add_topic(const Topic& topic);
    [[nodiscard]] bool add_topic(Subscriber_topic&& topic);

    // Bundle 的跨进程唤醒；local_wake_index 必须对应 $local_wake 事件。
    // notification 由 supervisor/Broker 创建，Recorder 只附着。
    [[nodiscard]] bool attach_wakeup(
        const std::string& bundle_name,
        std::shared_ptr<ipc::Notification> notification,
        int local_wake_index);

    explicit operator bool() const noexcept { return impl_ != nullptr; }

    [[nodiscard]] bool failed() const noexcept;
    [[nodiscard]] std::string error() const;

    bool record(Trigger::Ptr&& trigger);
    // 由 Broker/上层事件循环调用；唤醒录制线程立即 poll。
    void notify() noexcept;
    void start();
    void stop();

    [[nodiscard]] std::vector<Bundle_metrics> metrics() const;
    [[nodiscard]] bool set_write_mode(const std::string& bundle_name,
                                      Write_mode mode);

    // 由外部时间同步服务更新；只影响本地 UTC 估算，不改变 steady 时长。
    void update_time_sync(const time_::Time_sync_status& status,
                          std::int64_t max_adjust_ns = 0);

private:
    class Impl;
    std::unique_ptr<Impl> impl_;
};

}  // namespace data
